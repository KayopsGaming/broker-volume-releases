# Broker Specializations
The main goal of this addon is to provide a Data Broker icon/text to set the game volume, but you can use it in many other ways.

More information here: https://www.curseforge.com/wow/addons/data-broker-volume-controle
